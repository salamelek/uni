NAVODILA ZA UPORABO

1) Vpis:
	Preden lahko pošilja sporočila, client mora vnesti dovoljeno ime. Če z začetnem dialogom to ne gre, se ga lahko nastavi z ukazom "username <newUsername>"


2) Javna sporočila:
	Karkoli se napiše v terminal, bo poslano kot javno sporočilo


3) Privatna sporočila:
	sintaksa: msg <username> <message>
	Server bo poslal sporočilo le navedenemu uporabniku
