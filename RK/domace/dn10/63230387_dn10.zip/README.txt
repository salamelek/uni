NAVODILA

Certifikati: V client.py v vrsticah 84-86 so možni certifikati

Ukazi:
    /list:              prikaže seznam povezanih uporabnikov
    /msg <userName>:    Pošlje privatno sporočilo


Pripombe:
    - Ko se piše navadna sporočila, ne bodo poslana nazaj do pisatelja
    - Ni možna priključitev dveh odjemalcev z istim commonName